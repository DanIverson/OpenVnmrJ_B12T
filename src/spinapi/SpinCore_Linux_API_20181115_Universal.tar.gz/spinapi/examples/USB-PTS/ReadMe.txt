
---------------------------
SpinCore Technologies, Inc.
 http://www.spincore.com
---------------------------

Thank you for choosing SpinCore Technologies!


--------------------------------------------------------------
USB Interface to PTS Synthesizer (USB-PTS) examples directory.
--------------------------------------------------------------

This directory contains examples for use with SpinCore's USB-PTS device and a PTS frequency synthesizer.  The examples can be run by double clicking and then entering the desired frequency.

--------------------------------------------------------------
 USB-PTS_Controller - TCL/TK User Interface
--------------------------------------------------------------

This GUI allows for easy use of your USB-PTS device.  Run the GUI by double clicking the USB-PTS_Controller.exe file.  Select your device by using the radio buttons at the top of the  window (Note that even if your device is not listed, it should work by selecting PTS500.  


--------------------------------------------------------------
For more information please read the product manual availabe on our website at:
 http://www.spincore.com/CD/USB-PTS/USB-PTS_Manual.pdf

For any questions, comments or concerns please feel free to contact SpinCore Technologies at:

 http://www.spincore.com
 or +1-352-271-7383

--------------------------------------------------------------